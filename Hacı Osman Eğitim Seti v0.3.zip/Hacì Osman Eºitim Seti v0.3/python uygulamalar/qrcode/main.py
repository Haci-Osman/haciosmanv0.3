import qrcode

code = qrcode.make('https://menum.co/haciosman')
code.save('osman.png')

